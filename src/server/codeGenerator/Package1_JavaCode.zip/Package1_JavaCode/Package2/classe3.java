package Package1_JavaCode.Package2;
public final class classe3 
 { 
public String operazione4() { 
System.out.println("Sono l operazione4 della classe3!!");
 
 }; 
};