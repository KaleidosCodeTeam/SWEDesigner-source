package Package1_JavaCode.Package1;
import Package1_JavaCode.Package2.*;
public abstract class abstractClass 
 { 
protected final int attrAbs  = 2;
protected abstract String operAbs(); 
};