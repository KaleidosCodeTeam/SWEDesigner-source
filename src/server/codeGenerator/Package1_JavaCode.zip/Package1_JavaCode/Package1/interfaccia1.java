package Package1_JavaCode.Package1;
import Package1_JavaCode.Package2.*;
public interface interfaccia1 
 { 
public String operInterfaccia(char param1, param2); 
};