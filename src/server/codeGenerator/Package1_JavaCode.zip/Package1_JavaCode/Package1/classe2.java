package Package1_JavaCode.Package1;
import Package1_JavaCode.Package2.*;
public class classe2 implements interfaccia1 
 { 
private static classe1 attr1 ;
public String operInterfaccia(char param1,int param2) { 
while(param2 >0){ 
System.out.println(param1);
}
return "operInterfaccia da classe2"; 
 
 }; 
public static final classe3 operazione2() { 
return new classe3(); 
 
 }; 
public void setAttr1(classe1 at1) { 
attr1 = at1;
System.out.println(attr1.operazione1(5));
return new class3(); 
 
 }; 
};