function abstractClass()
 { 
this.operAbs = function() 
 { 
} 
} 
