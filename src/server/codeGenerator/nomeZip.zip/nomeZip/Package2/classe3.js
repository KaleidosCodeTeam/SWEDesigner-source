function classe3()
 { 
this.operazione4 = function() 
 { 
System.out.println("Sono l operazione4 della classe3!!");
} 
} 
