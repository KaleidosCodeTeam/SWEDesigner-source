function interfaccia1()
 { 
this.operInterfaccia = function(param1,param2) 
 { 
} 
} 
