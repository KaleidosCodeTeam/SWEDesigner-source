package PackageName;
public static final class NomeClasse2 extends NomeClasse1 
 { 
protected static final char nuovoAttributo2  = 'c';
private static final int nuovaOperazione2(String nuovoParametro2 = "sss") { 
 
 }; 
};