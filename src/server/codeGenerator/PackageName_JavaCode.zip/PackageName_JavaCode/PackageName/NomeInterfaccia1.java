package PackageName;
public interface NomeInterfaccia1 
 { 
public int oper3(char nuovoParametro4, nuovoParametro); 
public Object oper4( nuovoParametro); 
};