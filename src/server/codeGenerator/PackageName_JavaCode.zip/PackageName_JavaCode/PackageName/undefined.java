package PackageName;
public abstract class NomeClasse1 
 { 
private char nuovoAttributo1  = 'c';
public abstract int nuovaOperazione1(int nuovoParametro1=2); 
};
public static final class NomeClasse2 extends NomeClasse1 
 { 
protected static final char nuovoAttributo2  = 'c';
private static final int nuovaOperazione2(String nuovoParametro2 = "sss") { 
 
 }; 
};
public class NomeClasse3 implements NomeInterfaccia1 
 { 
private static final x nuovoAttributo5 ;
private int nuovoAttributo6  = 5;
protected y nuovoAttributo7 ;
};
public interface NomeInterfaccia1 
 { 
public int oper3(char nuovoParametro4, nuovoParametro); 
public Object oper4( nuovoParametro); 
};