package PackageName;
public abstract class NomeClasse1 
 { 
private char nuovoAttributo1  = 'c';
public abstract int nuovaOperazione1(int nuovoParametro1=2); 
};