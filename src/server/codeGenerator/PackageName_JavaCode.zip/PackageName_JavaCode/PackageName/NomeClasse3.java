package PackageName;
public class NomeClasse3 implements NomeInterfaccia1 
 { 
private static final x nuovoAttributo5 ;
private int nuovoAttributo6  = 5;
protected y nuovoAttributo7 ;
};