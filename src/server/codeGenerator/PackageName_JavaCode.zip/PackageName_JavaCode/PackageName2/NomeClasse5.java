package PackageName2;
public abstract static final class NomeClasse5 
 { 
private static final yy nuovoAttributo7 ;
private jj nuovoAttributo8 ;
private abstract int nuovaOperazione(); 
};