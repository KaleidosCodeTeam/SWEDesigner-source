function NomeClasse3()
 { 

 var freeze = function() { 
 Object.freeze(this); 
 }(); 
} 
NomeClasse3.nuovoAttributo5 = undefined;
