function NomeInterfaccia1()
 { 
this.oper3 = function(nuovoParametro4,nuovoParametro) 
 { 
} 
this.oper4 = function(nuovoParametro) 
 { 
} 
} 
