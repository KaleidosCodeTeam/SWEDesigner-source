function NomeClasse1()
 { 
this.nuovaOperazione1 = function(nuovoParametro1=2) 
 { 
} 
} 
