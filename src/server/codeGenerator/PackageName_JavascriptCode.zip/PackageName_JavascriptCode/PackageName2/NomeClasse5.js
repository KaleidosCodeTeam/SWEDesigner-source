function NomeClasse5()
 { 
var nuovaOperazione = function() 
 { 
} 

 var freeze = function() { 
 Object.freeze(this); 
 }(); 
} 
NomeClasse5.nuovoAttributo7 = undefined;
